package com.edj.utilities;

public class Constants {
    public static final String ENDPOINT="/an/endpoint";
    public static final String ENDPOINT1="/an/endpoint1";
}
