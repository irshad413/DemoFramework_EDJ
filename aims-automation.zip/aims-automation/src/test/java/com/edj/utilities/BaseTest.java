package com.edj.utilities;

import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import com.github.tomakehurst.wiremock.junit5.WireMockExtension;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.PageUrls;
import net.thucydides.model.util.EnvironmentVariables;
import org.junit.jupiter.api.extension.RegisterExtension;
import org.openqa.selenium.WebDriver;
import net.serenitybdd.model.environment.ConfiguredEnvironment;
import net.thucydides.model.configuration.SystemPropertiesConfiguration;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.time.temporal.ChronoUnit;

import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.wireMockConfig;

public class BaseTest extends PageObject {
    public String host = "http://localhost:8443";

    public BaseTest(WebDriver driver){
        super(driver);
        //new WireMockSetup(wm1.getRuntimeInfo());
    }

    public void waitForPageLoad(){
        waitForPageLoad(30);
    }

    public void waitForPageLoad(int timeOutInSeconds){
        withTimeoutOf(timeOutInSeconds, ChronoUnit.SECONDS).waitFor(ExpectedConditions.jsReturnsValue("return document.readyState === 'Complete'") );
    }

    public void setPageBaseUrl(String url){
        EnvironmentVariables environmentVariables = ConfiguredEnvironment.getEnvironmentVariables();
        SystemPropertiesConfiguration configuration = new SystemPropertiesConfiguration(environmentVariables);
        configuration.setDefaultBaseUrl(url);
        PageUrls pageUrls = new PageUrls(this, configuration);
        this.setPageUrls(pageUrls);
    }
}
