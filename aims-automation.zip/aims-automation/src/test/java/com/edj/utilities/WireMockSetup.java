package com.edj.utilities;

import io.cucumber.java.AfterAll;
import io.cucumber.java.BeforeAll;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;

public class WireMockSetup {
    private static final String WIREMOCK_PORT = System.getProperty("wiremock.port", "8443");
    private static final WireMockServer wireMockServer = new WireMockServer(WireMockConfiguration.options().
            port(Integer.parseInt(WIREMOCK_PORT)));

    @BeforeAll
    public static void setupWireMock() {
        System.out.println("----- Starting Wiremock Server -----");
        if (!wireMockServer.isRunning()) {
            wireMockServer.start();
            WireMock.configureFor("localhost", Integer.parseInt(WIREMOCK_PORT));
            setupStub();
        }
    }

    private static void setupStub() {
        WireMock.stubFor(WireMock.get(urlEqualTo(Constants.ENDPOINT1)).willReturn(aResponse()
                .withHeader("Content-Type", "application/json")
                .withBodyFile("ResponseEp1.json").withStatus(200)));
        WireMock.stubFor(WireMock.get(urlEqualTo(Constants.ENDPOINT)).willReturn(aResponse()
                .withHeader("Content-Type", "application/json")
                .withBody("You've reached a valid WireMock endpoint")
                .withStatus(200)));
    }

    @AfterAll
    public static void tearDownWireMock() {
        System.out.println("----- Stopping Wiremock Server -----");
        wireMockServer.stop();
    }
}
