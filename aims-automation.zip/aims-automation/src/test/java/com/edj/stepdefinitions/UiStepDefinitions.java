package com.edj.stepdefinitions;

import com.edj.steps.ui.StepHomePage;
import com.edj.steps.ui.StepLoginPage;
import com.edj.steps.ui.StepSearchPage;
import com.edj.steps.ui.StepSearchResultsPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.Assertions;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class UiStepDefinitions {

    //@Steps
    StepLoginPage loginPage;

    //@Steps
    StepHomePage homePage;

    //@Steps
    StepSearchPage searchPage;

    //@Steps
    StepSearchResultsPage searchResultsPage;


    @When("User enters {string} as search text")
    public void user_enters_as_search_text(String searchText) {
        searchPage.setSearchBox(searchText);
    }
    @Then("Results should be retrieved in webpage")
    public void results_should_be_retrieved_in_webpage() {
        System.out.println(searchResultsPage.getResultCount()+" is the result count retrieved");
    }
    @Then("Right Navigation pane should have Edward Jones organization")
    public void right_navigation_pane_should_have_edward_jones_organization() {
        //searchResultsPage.resultInRightNavigation();
    }

    @Given("User is on Google Page")
    public void user_is_on_google_page() {
        searchPage.open();
        Assertions.assertTrue(searchPage.getHomePageUrl().equalsIgnoreCase("https://www.google.co.in/"));
    }

    @Given("User is on Home page")
    public void openApplication() {
        loginPage.open();

    }

    @When("User enters username as {string}")
    public void enterUsername(String userName) {
        loginPage.inputUserName(userName);
    }

    @When("User enters password as {string}")
    public void enterPassword(String passWord) {
        loginPage.inputPassword(passWord);

        loginPage.clickLogin();
    }

    @Then("User should be able to login successfully")
    public void clickOnLoginButton() {

        assertTrue(homePage.getHomPageTitle().contains("Dashboard"));
    }

    @Then("User should be able to see error message {string}")
    public void unsuccessfulLogin(String expectedErrorMessage) {

        String actualErrorMessage = loginPage.errorMessage();
        assertEquals(expectedErrorMessage, actualErrorMessage);
    }

    @Then("User should be able to see error message {string} below username")
    public void missingUsername (String expectedErrorMessage) {

        String actualErrorMessage = loginPage.missingUsernameErrorMessage();
        assertEquals(expectedErrorMessage, actualErrorMessage);
    }
}
