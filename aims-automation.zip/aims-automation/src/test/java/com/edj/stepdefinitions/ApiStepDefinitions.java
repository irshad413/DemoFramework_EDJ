package com.edj.stepdefinitions;

import com.edj.steps.api.ApiSteps;
import com.edj.steps.api.ApiStepsEp1;
import com.github.tomakehurst.wiremock.junit5.WireMockExtension;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.jupiter.api.extension.RegisterExtension;

import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.wireMockConfig;
import static org.assertj.core.api.Assertions.assertThat;

public class ApiStepDefinitions {
    static int wireMockPort = 8273;

    @RegisterExtension
    static WireMockExtension wm1 = WireMockExtension.newInstance()
            .options(wireMockConfig().port(wireMockPort))
            .build();

    //@Steps
    ApiSteps apiSteps;

    ApiStepsEp1 apiStepsEp1;

    @When("user make GET request to {string}")
    public void userMakeGETRequestTo(String url) {
        apiSteps.getRequestForServiceEp(url);
    }
    @Then("user get the {int} response code")
    public void userGetTheResponseCode(Integer status) {
        apiSteps.assertSuccessCode(status);
    }

    @When("user make GET request to endpoint 1 {string}")
    public void userMakeGETRequestToEp1(String url) {
        apiStepsEp1.getRequestForServiceEp(url);
    }
    @Then("user get the {int} response code for endpoint 1")
    public void userGetTheResponseCodeEp1(Integer status) {
        apiStepsEp1.assertSuccessCodeEp(status);
    }

    @Then("verify company name contains {string}")
    public void verifyCompanyNameContains(String company) {
        apiStepsEp1.validateServiceResponseEp(company);
    }
}
