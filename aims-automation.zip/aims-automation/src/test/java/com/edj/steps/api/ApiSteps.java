package com.edj.steps.api;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static org.assertj.core.api.Assertions.assertThat;
import com.edj.utilities.BaseTest;
import com.github.tomakehurst.wiremock.client.WireMock;
import net.serenitybdd.annotations.Step;
import net.thucydides.model.util.EnvironmentVariables;
import org.openqa.selenium.WebDriver;
import io.restassured.response.Response;
import net.serenitybdd.core.Serenity;
import net.serenitybdd.rest.SerenityRest;

public class ApiSteps extends BaseTest {
    private EnvironmentVariables env;

    public ApiSteps(WebDriver driver) {
        super(driver);
    }

    @Step
    public void getRequestForServiceEp(String endPoint) {
        //mockTheResponse(endPoint);
        Response response = SerenityRest.when().get(endPoint);
        String respBody = response.getBody().asString();
        System.out.println(respBody);
        Serenity.setSessionVariable("response").to(respBody);
        Serenity.setSessionVariable("code").to(response.getStatusCode());
    }
    @Step
    public void assertSuccessCode(int status) {
        assertThat(Serenity.sessionVariableCalled("code").equals(status));
    }

    private void mockTheResponse(String endPoint) {
        WireMock.stubFor(WireMock.get(urlEqualTo(endPoint.substring(host.length()))).willReturn(aResponse()
                .withHeader("Content-Type", "application/json")
                .withBody("You've reached a valid WireMock endpoint")
                .withStatus(200)));


    }
}
