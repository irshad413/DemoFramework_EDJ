package com.edj.steps.ui;

import net.serenitybdd.annotations.DefaultUrl;
import net.serenitybdd.annotations.Step;
import net.serenitybdd.core.pages.PageObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.edj.utilities.BaseTest;

@DefaultUrl("https://google.co.in")
public class StepSearchPage extends BaseTest {

    @FindBy(xpath="//textarea[@aria-label='Search']")
    WebElement searchBox;

    @FindBy(xpath="//input[@aria-label='Google Search']")
    WebElement searchButton;

    public StepSearchPage(WebDriver driver) {
        super(driver);
    }

    @Step("Search using text")
    public void setSearchBox(String searchText) {
        getDriver().get("https://google.co.in");
        searchBox.sendKeys(searchText);
        searchButton.click();
    }

    @Step("Verify user is on search page")
    public String getHomePageUrl(){
        return getDriver().getCurrentUrl();
    }
}
