package com.edj.steps.api;

import com.edj.utilities.BaseTest;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.google.gson.JsonObject;
import com.jayway.jsonpath.JsonPath;
import io.restassured.response.Response;
import net.serenitybdd.annotations.Step;
import net.serenitybdd.core.Serenity;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.model.util.EnvironmentVariables;
import org.openqa.selenium.WebDriver;

import java.util.List;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static org.assertj.core.api.Assertions.assertThat;

public class ApiStepsEp1 extends BaseTest {
    private EnvironmentVariables env;

    public ApiStepsEp1(WebDriver driver) {
        super(driver);
    }

    public void getRequestForServiceEp(String endPoint) {
        //mockTheResponse(endPoint);
        Response response = SerenityRest.when().get(endPoint);
        String respBody = response.getBody().asString();
        System.out.println(respBody);
        Serenity.setSessionVariable("response").to(respBody);
        Serenity.setSessionVariable("code").to(response.getStatusCode());
    }
    @Step
    public void assertSuccessCodeEp(int status) {
        assertThat(Serenity.sessionVariableCalled("code").equals(status));
    }

    @Step
    public void validateServiceResponseEp(String company){
        List<String> companies = JsonPath.read(Serenity.sessionVariableCalled("response").toString(), "$.[*].company");
        assertThat(companies.contains(company));
        //return Serenity.sessionVariableCalled("response");
    }

    private void mockTheResponse(String endPoint) {
        WireMock.stubFor(WireMock.get(urlEqualTo(endPoint.substring(host.length()))).willReturn(aResponse()
                .withHeader("Content-Type", "application/json")
                .withBodyFile("ResponseEp1.json").withStatus(200)));
    }
}
