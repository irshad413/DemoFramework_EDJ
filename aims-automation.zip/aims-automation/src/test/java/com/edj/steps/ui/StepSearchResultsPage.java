package com.edj.steps.ui;

import net.serenitybdd.annotations.Step;
import net.serenitybdd.core.pages.PageObject;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class StepSearchResultsPage extends PageObject {
    @FindBy(xpath="//div[@role='heading'][text()='Edward Jones Investments']")
    WebElement resultRightNavigation;

    @FindBy(id="result-stats")
    WebElement resultStats;

    @Step("Get result count")
    public String getResultCount() {
        return resultStats.getText();
    }

    @Step("Highlight main result")
    public void resultInRightNavigation(){
        getJavascriptExecutorFacade().executeScript("arguments[0].style.border='2px solid red'", resultRightNavigation);
        /*JavascriptExecutor jsExecutor = (JavascriptExecutor) getDriver();
        jsExecutor.executeScript("arguments[0].style.border='2px solid red'", resultRightNavigation);*/
    }
}
